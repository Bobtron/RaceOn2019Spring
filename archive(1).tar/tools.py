from scipy.signal import find_peaks, butter, filtfilt


def printFrame(frame, subdivisions):
    b, a = butter(3, 0.02)
    return frame